#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "LED.h"
#include "Key.h"

uint8_t KeyNum = 0;
int main()
{
	//初始化LED配置
	LED_Init();
	//初始化Key配置
	KEY_Init();
	while(1)
	{
		KeyNum =Key_GetNum();//把按键读取的值返回来，然后就去启动对应的LED
		if(KeyNum==1)
		{
			//只有这一行就是按下亮，不按下就灭了
//			LED1_ON();
		
		//  如果你想按下之后，亮，再按一次就熄灭
//			还需要再加上一点东西，就是读取该引脚的
//			情况，使用read——output——这个函数
		//这样就能一个按键控制两个状态了，控制开关两个状态
		//一开始先把led弄到关闭状态，然后开始按按钮进行开关
			// LED1_OFF();这里加一个关闭为什么就不行了？
			//因为你每次按下按键都是从if这里重新开始执行，就算你
			//翻转电平了都无济于事，先执行的off关上了然后立马开始
			//执行turn把电平反转过来了，然后就是亮的状态了
			//下次按按钮进来这里只会一直开灯
		//此时开始按按钮
		LED1_Turn();
		
		}
		if(KeyNum==2)
		{
			//同上
			//按下左边的按键让这个熄灭
			LED2_Turn();
		
		}
		
	}
	
}

