#include "stm32f10x.h"                  // Device header
#include "Delay.h"//延时头文件

void KEY_Init(void)
{
	//初始化时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	//GPIOB结构体
	GPIO_InitTypeDef GPIO_InitStructure;
	////读取按键，上拉输入,也就是那个高电平，按下按键低电平LED就
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_11 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	//初始化GPIOB
	
	GPIO_Init(GPIOB,&GPIO_InitStructure);
	
}

uint8_t Key_GetNum(void)
{
	uint8_t KeyNum =0;
	//引脚1对应led的1
	if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1)==0)
	{
		//按键按下去的时候消抖,防止闪烁
		Delay_ms(20);
		//如果按键一直按下，程序就卡在这里直到松手再继续下面的操做
		while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1)==0);
		//松手之后再次消抖
		Delay_ms(20);
		KeyNum = 1 ;//把这个值传回去，然后赋值给对应的外设，启动对应外设
	}
	
	//引脚11对应led的2
	if(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11)==0)
	{
		//按键按下去的时候消抖,防止闪烁
		Delay_ms(20);
		//如果按键一直按下，程序就卡在这里直到松手再继续下面的操做
		while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_11)==0);
		//松手之后再次消抖
		Delay_ms(20);
		KeyNum = 2 ;//这里对应的是引脚2，这个定义成
		
		//把这个值传回去，然后赋值给对应的外设，启动对应外设
	}
	return KeyNum;
}

