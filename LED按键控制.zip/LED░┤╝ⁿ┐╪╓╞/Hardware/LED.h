#ifndef __LED_H //如果没有定义这个字符串就编译下面的这个
//也就是可以执行，这里，这里是防止重复定义的
#define __LED_H
void LED_Init(void);//函数声明
void LED1_ON(void); //
void LED1_OFF(void);
void LED2_ON(void);
void LED2_OFF(void);
void LED1_Turn(void); //翻转led1电平
void LED2_Turn(void);//翻转led2电平
#endif //与#ifndef 配对使用，结束标志


