#include "stm32f10x.h"                  // Device header

//写一个LED初始化函数

void LED_Init(void)
{
	//初始化时钟
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
	
	//GPIOA结构体
	GPIO_InitTypeDef GPIO_InitStructure;
	//
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_1 | GPIO_Pin_2 ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	//初始化GPIOA
	GPIO_Init(GPIOA,&GPIO_InitStructure);
	
	//GPIOA配置好之后默认是低电平
	//把这两个引脚置高电平
	GPIO_SetBits(GPIOA,GPIO_Pin_1 | GPIO_Pin_2);
	
}

void LED1_ON(void)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_1);//置低电平，led1亮
}

void LED1_OFF(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_1);//置低电平，led1不亮
}

void LED2_ON(void)
{
	GPIO_ResetBits(GPIOA,GPIO_Pin_2);//置低电平，led2亮
}

void LED2_OFF(void)
{
	GPIO_SetBits(GPIOA,GPIO_Pin_2);//置低电平，led2不亮
}
void LED1_Turn(void)//实现电平翻转功能，开关LED
{
	
	if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_1)==0)
		//读取这个引脚0的状态，返回对应的值,如果为低电平就返回0
	//高电平就返回1
	{
		//如果为0，说明低电平，我把它翻转成高电平
		GPIO_SetBits(GPIOA,GPIO_Pin_1);//1号置高电平（led1不亮）
	}
	else
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_1);//1号置低电平（led1亮）
	}
	
}
void LED2_Turn(void)//实现电平翻转功能，开关LED
{
	
	if(GPIO_ReadOutputDataBit(GPIOA,GPIO_Pin_2)==0)
		//读取这个引脚0的状态，返回对应的值,如果为低电平就返回0
	//高电平就返回1
	{
		//如果为0，说明低电平，我把它翻转成高电平
		GPIO_SetBits(GPIOA,GPIO_Pin_2);//2号置高电平（led2不亮）
	}
	else
	{
		GPIO_ResetBits(GPIOA,GPIO_Pin_2);//2号置低电平（led2亮）
	}
	
}
