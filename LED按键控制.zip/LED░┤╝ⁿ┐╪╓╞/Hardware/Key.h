#ifndef __KEH_H
#define __KEH_H

uint8_t Key_GetNum(void); //返回按键的选择
void KEY_Init(void);//初始化按键配置


#endif
