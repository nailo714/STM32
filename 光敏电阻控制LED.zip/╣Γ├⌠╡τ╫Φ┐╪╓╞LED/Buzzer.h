#ifndef __BUZZER_H

#define __BUZZER_H
void BuzzerInit(void);//给蜂鸣器要用的引脚初始化配置
void BuzzerON(void); //打开蜂鸣
void BuzzerOFF(void);  //关闭蜂鸣器

#endif 
