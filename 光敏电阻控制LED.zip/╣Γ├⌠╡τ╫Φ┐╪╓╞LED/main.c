#include "stm32f10x.h"                  // Device header
#include "LDR.h"
#include "Buzzer.h"

//初始化一个参数，存放读取到光敏传感器模块输出的值
uint8_t ReadNum  = 0; 
int main()
{
	//初始化蜂鸣器
	BuzzerInit();
	//初始化光敏传感器
	LDRInit();
	//给这个参数赋值，进入判断
	
	while(1)
	{
		//这个参数不能放循环外面呢，否则你一直都是那个状态
		ReadNum = ReadLDR();//读取到高电平输出1，低电平输出0
		if(ReadNum == 1)//遮住蜂鸣器时
			//读取到低电平就不反转
		{
			BuzzerON();//打开
		}
		else
		{
			BuzzerOFF();//关掉蜂鸣器
		}
	}
}

