#include "stm32f10x.h"                  // Device header

//启动蜂鸣器对应的时钟引脚
//初始化时钟GPIOB
void BuzzerInit(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	//结构体
	GPIO_InitTypeDef GPIO_InitStructure;
	//推挽输出
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	//12引脚
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
	//输出频率
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	//初始化
	GPIO_Init(GPIOB,&GPIO_InitStructure);
}

//这里不可以用翻转电平
//反转电平是什么时候用呢？
//比如说你在同一个引脚，你的目的是同一个状态（比如同一个电平——按键按下），控制两种状态，即按下开（关），再次按下（亮），这种
// 而这里是，你光敏传感器，一种状态对应一个蜂鸣器的状态，这里用翻转电平也可以，但是观感不行，你两种状态都反转，就显得逻辑不够好


//这里的需求是你会读取到两个值，读到1就开，读到0就关
void BuzzerOFF(void)
{
	//推挽输出默认为高电平，因此如果低电平了就会响，及时推挽输出也设置高电平，加强高电平的稳定性
	GPIO_SetBits(GPIOB,GPIO_Pin_12);//高电平，不响
}
void BuzzerON(void)
{
		GPIO_ResetBits(GPIOB,GPIO_Pin_12);//置低电平然后响
}

