#include "stm32f10x.h"                  // Device header

//初始化该引脚
void LDRInit(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB,ENABLE);
	
	//结构体
	GPIO_InitTypeDef GPIO_InitStructure;
	//读取模式，上拉电平(也就是说初始值为高电平)
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	//12引脚
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
	//输出频率
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	
	//初始化
	GPIO_Init(GPIOB,&GPIO_InitStructure);
}

uint8_t ReadLDR(void)
{
	uint8_t ReadNum = 0;
	//读取这个引脚的置然后返回对应的值，高电平设置为1，低电平设置为0啥的
	if(GPIO_ReadInputDataBit(GPIOB,GPIO_Pin_13)==0)
	{
		ReadNum = 0;
		//读取到0就一直在这里不进入下一步
		
	}
	else
	{
		ReadNum = 1;
	}
	return ReadNum;
}


	