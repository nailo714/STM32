#ifndef __LDR_H

#define __LDR_H
void LDRInit(void); //初始化
uint8_t ReadLDR(void); //读取引脚电平返回0或1


#endif 
